#include <zlib.h>

int main() {
    zlibVersion();
    return 0;
}